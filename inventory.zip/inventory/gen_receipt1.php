<?php
require_once("dbcontroller.php");
require_once("includes/connection.php");
$db_handle = new DBController();
 if(isset($_POST['sales_button']) && ($_POST['cust']=='--SELECT--')){ 
			echo "<script> alert('Please select customer!')</script>";	
			echo "<script>document.location = 'receipt.php'</script>";			
		}
	if(isset($_POST['sales_button']) && ($_POST['salesdate']=='--SELECT--')){ 
			echo "<script> alert('Please select sales date!')</script>";	
			echo "<script>document.location = 'receipt.php'</script>";			
		}
if(isset($_POST['sales_button'])){ 
	$customer=$_POST['cust'];
	$date1=$_POST['salesdate'];
}
$header = "MB Merchandising, INC.";
$header1 = "Abar 1st, San Jose City, Nueva Ecija";
$title = "Sales Receipt";

	$date = DateTime::createFromFormat('M j, Y', $date1);
	$date2=$date->format('Y-m-d');
	

$columnname1 = "Item Name";
$columnname2 = "Quantity";
$columnname3 = "Selling Price";
require('fpdf/fpdf.php');
$pdf = new FPDF();
$pdf->SetMargins(23, 10, 0, 10); 
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);	
$pdf->Cell(170,12,$header,0,0,'C');
$pdf->Ln(5);
$pdf->Cell(170,12,$header1,0,0,'C');
$pdf->Ln(15);
$pdf->SetFont('Arial','',14);
$pdf->Cell(170,12,$title,0,0,'C');
$pdf->Ln(10);
$pdf->Cell(170,12,'Customer: ' .$customer,0);	
$pdf->Ln(5);
$pdf->Cell(170,12,'Date: ' .$date1,0);	
$pdf->Ln(15);
$pdf->SetFont('Arial','B',14);
$pdf->Cell(70,12,$columnname1,1,0,'C');
$pdf->Cell(35,12,$columnname3,1,0,'C');
$pdf->Cell(30,12,$columnname2,1,0,'C');
$pdf->Cell(25,12,'Total',1,0,'C');
$total=0;
$sq=mysqli_query($con,"select customer_id from customer where sold_to like '$customer'");
	$row2=mysqli_fetch_array($sq);
	$id=$row2['customer_id'];
$sql = mysqli_query($con,"SELECT sales_id FROM sales where customer_id='$id' && sales_date='$date2'");
while($row= mysqli_fetch_array($sql)){
	$sales_id=$row['sales_id'];
	$sql1 = mysqli_query($con,"SELECT * FROM item_list_sold where sales_id='$sales_id'");
	while($row1= mysqli_fetch_array($sql1)){
	$tot=0;
	$pdf->SetFont('Arial','',12);	
	$pdf->Ln();
	$item=$row1['item_sold_name'];
	$sprice=$row1['selling_price'];
	$quan=$row1['quantity_sold'];
	$tot=$sprice*$quan;
	$total+=$tot;
		$pdf->Cell(70,12,'   '.$item,1);
		$pdf->Cell(35,12,$sprice,1,0,'C');
		$pdf->Cell(30,12,$quan,1,0,'C');
		$pdf->Cell(25,12,$tot,1,0,'C');
		
	}
}

$pdf->Ln();

$pdf->Cell(160,12,'Total: '.$total .'       ',1,0,'R');
$pdf->Ln(20);
$pdf->Output();
?>