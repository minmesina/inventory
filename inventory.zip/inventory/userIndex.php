<!DOCTYPE html>
<?php
include("cssmenu.php");
require_once("includes/connection.php");
?>

<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	 <script language="JavaScript" type="text/javascript">
  function login(showhide){
    if(showhide == "show"){
        document.getElementById('popup').style.visibility="visible";
        
    }else if(showhide == "hide"){
        document.getElementById('popup').style.visibility="hidden";
    }
  }
  </script>
	<title></title>
</head>
<body background="images/bg1.jpg">
	<div class="container">
	    
	
	<div id= "slider" style='border-radius: 10px 10px 10px 10px; border: 10px outset cyan;'>
		<img src = "images/img1.jpg" />
		<img src = "images/img2.jpg"/>
	</div>

	</div>

	


</body>
</html>
