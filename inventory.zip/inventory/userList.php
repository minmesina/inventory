<!DOCTYPE html>
<?php 
require_once("includes/connection.php");
include("cssmenu.php");
?>
<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/cont_style.css">
	<title></title>
</head>
<body background="images/bg1.jpg">
<div class="s">Search:<input type="Text" name="search" id="search" onkeyup="ajaxFunction(this.value);"></div>
	<div id="suggest"></div>
	<div class="container">
	<div>
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="list">     
					<h1 class="label1">Current Stocks</h1>
					<table border="1" width="100%" style="border: 2px dotted #31b7f1;">
					<thead>
						<th>Item Name<br></th>
						<th>Quantity<br></th>
					</thead>
					<?php
					$result=mysqli_query($con,"select * from item where item_quantity >= 1 order by item_quantity ASC");
					while($row = mysqli_fetch_array($result))
							{ ?>
							<tr>            	
								<td style="text-align:left;">&emsp;<?php echo $row['item_name']?></td>
								<td width="20%"><?php echo $row['item_quantity']?></td>	
							</tr>                      
						<?php } ?>
					</table>
					</div>
				</div>
			</div>
		</div>
	</div>	
	</div>
		
</body>
</html>
<script type="text/javascript">
function ajaxFunction(str)
{
	
	document.getElementById("list").style.display='none'; 
	 if(str==null || str==""){
		document.getElementById("list").style.display='inline';  
	 }
	
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }
function stateChanged() 
    {
    if(httpxml.readyState==4)
      {
document.getElementById("suggest").innerHTML=httpxml.responseText;
document.getElementById("msg").style.display='none';

      }
    }
	var url="search.php";
url=url+"?txt="+str;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("msg").style.display='inline';

  }
</script>