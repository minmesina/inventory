<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
?>
<html>
<head>
	<link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/cont_style.css">
	<title>Manage Customer</title>
</head>
<body background="images/bg1.jpg">
	<div>
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="record_customer">
          			<form name="c_form" id="c_form" action="" method="POST">
							<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="sales.php">X</a>
							<h3>Customer Name:</h3> 
							<input  id="c_name" name="c_name" required="required" type="text"/>
							<h3>Address:</h3> 
							<input  id="address" name="address" required="required" type="text"/>
							<h3>TIN:</h3> 
							<input  id="tin" name="tin" type="text"/>
							<h3>Business Style:</h3> 
							<input  id="b_style" name="b_style" type="text"/>
							<h3>Terms:</h3> 
							<input  id="terms" name="terms" type="text"/>
							<br><br>
							<input type="submit" name="cust_info" value="Save">
							<?php
							if(isset($_POST['cust_info'])){ 
								$c_name = $_POST['c_name'];
								$address = $_POST['address'];
								$tin = $_POST['tin'];
								$b_style = $_POST['b_style'];
								$terms = $_POST['terms'];
								$sql = "Insert into customer(sold_to, address, TIN, business_style,terms) values('$c_name','$address','$tin','$b_style','$terms')";
								$result = mysqli_query($con,$sql);?>
								<script> alert('Succesfully Added!');</script>		
							<?php } ?>
							
						</form>  
											
					</div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>
