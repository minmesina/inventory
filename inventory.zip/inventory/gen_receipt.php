<?php
require_once("dbcontroller.php");
require_once("includes/connection.php");
$db_handle = new DBController();
 if(isset($_POST['receipt_button']) && ($_POST['opt']=='--SELECT--')){ 
			echo "<script> alert('Please select supplier!')</script>";	
			echo "<script>document.location = 'receipt.php'</script>";			
		}
	if(isset($_POST['receipt_button']) && ($_POST['deldate']=='--SELECT--')){ 
			echo "<script> alert('Please select delivery date!')</script>";	
			echo "<script>document.location = 'receipt.php'</script>";			
		}
if(isset($_POST['receipt_button'])){ 
	$supplier=$_POST['opt'];
	$date1=$_POST['deldate'];
}
$header = "MB Merchandising, INC.";
$header1 = "Abar 1st, San Jose City, Nueva Ecija";
$title = "Delivery Receipt";

	$date = DateTime::createFromFormat('M j, Y', $date1);
	$date2=$date->format('Y-m-d');
	

$columnname1 = "Item Name";
$columnname2 = "Quantity";
$columnname3 = "Unit Price";
require('fpdf/fpdf.php');
$pdf = new FPDF();
$pdf->SetMargins(23, 10, 0, 10); 
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);	
$pdf->Cell(170,12,$header,0,0,'C');
$pdf->Ln(5);
$pdf->Cell(170,12,$header1,0,0,'C');
$pdf->Ln(15);
$pdf->SetFont('Arial','',14);
$pdf->Cell(170,12,$title,0,0,'C');
$pdf->Ln(10);
$pdf->Cell(170,12,'Supplier: ' .$supplier,0);	
$pdf->Ln(5);
$pdf->Cell(170,12,'Date: ' .$date1,0);	
$pdf->Ln(15);
$pdf->SetFont('Arial','B',14);
$pdf->Cell(70,12,$columnname1,1,0,'C');
$pdf->Cell(35,12,$columnname3,1,0,'C');
$pdf->Cell(30,12,$columnname2,1,0,'C');
$pdf->Cell(25,12,'Total',1,0,'C');
$total=0;
$sql = mysqli_query($con,"SELECT delivery_ID FROM delivery where supplier_name='$supplier' && delivery_date='$date2'");
while($row= mysqli_fetch_array($sql)){
	$id=$row['delivery_ID'];
	$sql1 = mysqli_query($con,"SELECT * FROM delivery_list where del_id='$id'");
	while($row1= mysqli_fetch_array($sql1)){
	$tot=0;
	$pdf->SetFont('Arial','',12);	
	$pdf->Ln();
	$item=$row1['item_name'];
	$uprice=$row1['unit_price'];
	$quan=$row1['item_quantity'];
	$tot=$uprice*$quan;
	$total+=$tot;
		$pdf->Cell(70,12,'   '.$item,1);
		$pdf->Cell(35,12,$uprice,1,0,'C');
		$pdf->Cell(30,12,$quan,1,0,'C');
		$pdf->Cell(25,12,$tot,1,0,'C');
		
	}
}

$pdf->Ln();

$pdf->Cell(160,12,'Total: '.$total .'       ',1,0,'R');
$pdf->Ln(20);
$pdf->Output();
?>