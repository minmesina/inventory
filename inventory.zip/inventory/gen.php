<?php
require_once("dbcontroller.php");
require_once("includes/connection.php");
$db_handle = new DBController();

if(isset($_POST['sb_button'])){ 
	$from=$_POST['sb_from'];
	$to=$_POST['sb_to'];
}
$header = "MB Merchandising, INC.";
$header1 = "Abar 1st, San Jose City, Nueva Ecija";
$title = "Summary of Item Bought";
$label = "Note: It shows the most purchased items to least purchased items";

	$date = DateTime::createFromFormat('Y-m-d', $from);
	$m=$date->format('M j, Y');
	$date = DateTime::createFromFormat('Y-m-d', $to);
	$n=$date->format('M j, Y');

$columnname1 = "Item Name";
$columnname2 = "Quantity";
require('fpdf/fpdf.php');
$pdf = new FPDF();
$pdf->SetMargins(23, 10, 0, 10); 
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);	
$pdf->Cell(170,12,$header,0,0,'C');
$pdf->Ln(5);
$pdf->Cell(170,12,$header1,0,0,'C');
$pdf->Ln(10);
$pdf->SetFont('Arial','',14);
$pdf->Cell(170,12,$title,0,0,'C');
$pdf->Ln(5);
$pdf->Cell(170,12,$m .' - ' .$n,0,0,'C');	
$pdf->Ln(20);
$pdf->SetFont('Arial','B',14);
$pdf->Cell(70,12,$columnname1,1,0,'C');
$pdf->Cell(35,12,'Selling Price',1,0,'C');
$pdf->Cell(30,12,$columnname2,1,0,'C');
$pdf->Cell(25,12,'Total',1,0,'C');
$result = mysqli_query($con,"SELECT sales_id as id FROM sales where sales_date between '$from' and '$to'");
while($row= mysqli_fetch_array($result)){
	$id=$row['id'];
	$sql1 = mysqli_query($con,"SELECT * FROM item_list_sold where sales_id='$id' order by quantity_sold DESC");
	while($row1= mysqli_fetch_array($sql1)){
	$tot=0;
	$pdf->SetFont('Arial','',12);	
	$pdf->Ln();
	$item=$row1['item_sold_name'];
	$sprice=$row1['selling_price'];
	$quan=$row1['quantity_sold'];
	$tot=$sprice*$quan;
		$pdf->Cell(70,12,'   '.$item,1);
		$pdf->Cell(35,12,$sprice,1,0,'C');
		$pdf->Cell(30,12,$quan,1,0,'C');
		$pdf->Cell(25,12,$tot,1,0,'C');
	}
}

$pdf->Ln(20);
$pdf->Output();
?>