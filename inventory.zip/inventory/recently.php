<!DOCTYPE html>
<?php 
require_once("includes/connection.php");
include("cssmenu.php");
?>
<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<title></title>
</head>
<body background="images/bg1.jpg">
	<div class="container">
	<div style="margin-top:-20px;">
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="list1">     
	<h1 class="label1" style="margin-left:0%;">Recently Added Items</h1>
	<form name="reform" method="POST" action="" id="reform" enctype="multipart/form-data">
		<label style='margin-left:20%;'>From:</label>
		<input style='width:30%; margin-left:10%;' type="date" name="re_from"><br>
		<label style='margin-left:20%;'>To:</label>
		<input style='width:30%; margin-left:15%;' type="date" name="re_to"/><br>
		<input style='width:35%; margin-left:43%; padding-left: 2%;' type="Submit" name="re_button" value="Enter"/><br><br>
		<?php 
	
			
		 if(isset($_POST['re_button'])){
		$from=$_POST['re_from'];
		$to=$_POST['re_to'];	
		$sql1= mysqli_query($con,"SELECT delivery_ID as del_id from delivery where delivery_date between '$from' and '$to'");
		$cn=mysqli_query($con,"SELECT count(delivery_ID) as num from delivery where delivery_date between '$from' and '$to'");
		$cnt= mysqli_fetch_array($cn);
		$x=$cnt['num'];
		
		echo("<table border='1' width='100%' style='border: 2px dotted #31b7f1;'>
				<thead>
					<th>Item Name&emsp;&emsp;<br></th>
					<th>Quantity<br></th>
				</thead>");
		
		while($row1=mysqli_fetch_array($sql1)){
			$del_id=$row1['del_id'];
			$sql2= mysqli_query($con,"SELECT * from delivery_list where del_id like '$del_id'");
			while($row2=mysqli_fetch_array($sql2)){
				$itemname=$row2['item_name'];
				$itemquantity=$row2['item_quantity'];
				echo("<tr style='text-align:left;'><td>&emsp;$itemname</td>"); 
				echo("<td width='20%' style='text-align:center;'>$itemquantity</td></tr>");
			}
		}echo("</table>");
		if($x<=0){
		echo("&emsp;&emsp;<i>No Item Delivered (From: $from To: $to)</i>");
		}		
		}?>
	</form><br><br>
	
	
	
	</div>
				</div>
			</div>
		</div>
	</div>	
    </div>
</body>
</html>

