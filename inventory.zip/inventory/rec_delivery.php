<!DOCTYPE html>
<?php 
require_once("includes/connection.php");
?>	

<html>
<head>
</head>
<body>

<?php

if(isset($_POST['done'])){ 

	$prod_name=$_POST['itemm'];
	$prod_type=$_POST['prod_type'];
	$unit_price=$_POST['unit_price'];
	$quantity=$_POST['quantity'];
	$sql1= mysqli_query($con,"SELECT category_id as cat_id from category where category_name='$prod_type'");
	                  $row= mysqli_fetch_array($sql1);
					  $catid=$row['cat_id'];
	$sql2 = "INSERT INTO delivery_list (del_id,item_category_id,item_name,item_quantity,unit_price) VALUES ('1','$catid','$prod_name','$quantity','$unit_price')";
	if (!mysqli_query($sql2,$con))
					{
					die('Error querying database' . mysqli_error());
					}
					echo "<script> alert('Succesfully Added!')</script>";
					echo "<script type='text/javascript'>document.location = 'prod_delivery.php'</script>";

					
					} 					
?>
<?php
if(isset($_POST['save'])){ 
mysqli_query($con,"INSERT INTO delivery (delivery_date,total_Price,supplier_name) VALUES (now(),'total','supplier')");
}?>
</body>
</html>