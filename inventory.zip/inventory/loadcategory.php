<?Php
require "config.php";
$in=$_GET['txt'];

$msg="";
$msg .="<label>Item Category:</label></br>";
if(strlen($in)>0 and strlen($in) <20 ){
	$s="select * from item where item_name like '$in'";
	foreach($dbo->query($s) as $row){
		$c_id=$row['item_category_id'];
		$s_price=$row['selling_price'];
		
		$cat_quer="select category_name from category where category_id like '$c_id'";
		foreach($dbo->query($cat_quer) as $row1){ 
		$c_name=$row1['category_name'];
	
		
	$msg .="<input type='text' name='prod_type' class='labelx' value='$row1[category_name]'></br></br>";
	$msg .="<label>Selling Price:</label></br>";
	$msg .="<input type='text' name='s_price' class='labelx' value='$row[selling_price]'></br></br>";
		}
	}
		}

echo $msg;
?>