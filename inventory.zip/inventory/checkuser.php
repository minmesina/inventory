<?php
//connection ng database
$con = mysqli_connect("localhost","root","");
	if(!$con)
		{
		die("Could not connect: " . mysql_error());
		}
		mysqli_select_db("mb_database",$con);
		
	//get the value from index.php
	$un = $_POST['un'];
	$pw = $_POST['pw'];
	
	//check if the username and password are in db
	$sql = "SELECT * FROM accounts WHERE username='$un' AND password='$pw'";
	$result = mysqli_query($con,$sql);
	$count = mysqli_num_rows($result);
	if($count!=0)
		{
				
				header("location: userIndex.php");
        }
	else
		die('Username and Password does not match <br/>
			<a href="index.php"> click to go back</a>'.mysqli_error());
			
?>