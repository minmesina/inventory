<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
error_reporting(0);
?>
<html>
<head> 
	<title>Manage Category</title>
	<script language="JavaScript" type="text/javascript">
	  function update_cat(showhide){
		if(showhide == "show"){
			document.getElementById('popup3').style.visibility="visible";
			
		}else if(showhide == "hide"){
			document.getElementById('popup3').style.visibility="hidden";
		}
	  }
	</script>
	<script language="JavaScript" type="text/javascript">
	  function add_cat(showhide){
		if(showhide == "show"){
			document.getElementById('popup2').style.visibility="visible";
			
		}else if(showhide == "hide"){
			document.getElementById('popup2').style.visibility="hidden";
		}
	  }
	</script>
</head>
<body background="images/bg1.jpg">		
	<div class="container">
	<div>
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="cat1">
					<form id="catform" method="GET" Action="">
					<h1 class="label1">Category List</h1>
						<select name="selcat" id="selcat" onchange="change(this)">
							<option selected>--Select--</option>
								<?php $q1=mysqli_query($con,"select category_name from category");
								while($row1 = mysqli_fetch_array($q1)){ ?>
							<option id="cat_name" name="cat_name"><?php echo $row1['category_name']?></option>                      
								<?php } ?>
						</select> 
						<h2 class="label2">Category Name:</h2>
							<?php $categoryname=$_GET['selcat']; ?>
						<label class="label3"><?php echo $categoryname; ?></label> 
											
					</form>
					<br>
					<button style='width:30%; margin-left:0%; padding-left: 2%; background: rgb(247, 247, 247); border-radius: 2px;  box-shadow: 0pt 2px 5px rgba(105, 108, 109,  0.7),  0px 0px 8px 5px rgba(208, 223, 226, 0.4) inset;'><a href="javascript:add_cat('show')" style="text-decoration:none; font-size:110%; color:black; ">Add</a></button>
					<button style='width:30%; margin-left:0%; padding-left: 2%; background: rgb(247, 247, 247); border-radius: 2px;  box-shadow: 0pt 2px 5px rgba(105, 108, 109,  0.7),  0px 0px 8px 5px rgba(208, 223, 226, 0.4) inset;'><a href="javascript:update_cat('show')" style="text-decoration:none; font-size:110%; color:black; ">Update</a></button>
					<button style='width:30%; margin-left:0%; padding-left: 2%; background: rgb(247, 247, 247); border-radius: 2px;  box-shadow: 0pt 2px 5px rgba(105, 108, 109,  0.7),  0px 0px 8px 5px rgba(208, 223, 226, 0.4) inset;'><a href='delcat.php?selcat=<?php echo $categoryname; ?>' style="text-decoration:none; font-size:110%; color:black; ">Delete</a></button>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div style="padding-left:100px;" id="popup2">
  		<div class="container1">
    		<div id="container_demo">
      			<div id="wrapper">
        			<div id="cat2">
						<form name="addform" id="addform" action="category.php" method="POST">
							<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="category.php">X</a>	
							<h1>Category Name:</h1> 
							<input  id="add_cname" name="add_cname" required="required" type="text"/>
							<input type="submit" name="save" value="Save" >	
						</form> 
						<?php
						if(isset($_POST['save'])){ 
						$c_name = $_POST['add_cname'];
						$sql1 = mysqli_query($con,"Insert into category(category_name) values('$c_name')");
						?><script>document.location = "category.php"
						alert('Successfully Added!');</script>"
						<?php } ?>					
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div style="padding-left:100px;" id="popup3">
  		<div class="container1">
    		<div id="container_demo">
      			<div id="wrapper">
        			<div id="cat2">
						<form name="updateform" id="updateform" action="" method="POST">
							<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="category.php">X</a>
							<?php $pre_name = $_GET['selcat']; ?>
							<h1>Category Name:</h1> 
							<input  id="up_cname" name="up_cname" value="<?php echo $pre_name; ?>" required="required" type="text"/>
							<input type="submit" name="update" value="Update" >	
						</form>
						
						<script type="text/javascript">
								function change(sel){	
								var catx = sel.options[sel.selectedIndex].text
								window.location.href="?selcat="+catx;}
							</script>
						<?php
						if(isset($_POST['update'])){ 
						$up_cname = $_POST['up_cname'];
						$pre_name = $_GET['selcat'];
						$sql2 = mysqli_query($con,"select category_id from category where category_name like '$pre_name'");
						$row2 = mysqli_fetch_array($sql2);
						$catid=$row2['category_id'];
						$sql3 = mysqli_query("Update category set category_name='$up_cname' where category_id='$catid'");
						?><script>document.location = "category.php";
						alert('Successfully Updated!');</script>	
						<?php }
						?>
											
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
