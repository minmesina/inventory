<!DOCTYPE html>
<?php 
require_once("includes/connection.php");
include("cssmenu.php");
?>
<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<title></title>
</head>
<body background="images/bg1.jpg">
	<div class="container" >
		<div style="margin-top:-20px;">
			<div id="wrapper1">
				<div id="receipt1">     
				<h1 class="label1" style="margin-left:0%;">Delivery Receipt</h1>
				<form name="reform" method="POST" action="gen_receipt.php" id="receipt" enctype="multipart/form-data">
				<label style="margin-left:4%; font-size:130%;"><b>Supplier:</b></label>
				<select name="opt" id="opt" style="margin-left:8%; width:50%;" onchange="ajaxFunction(this.value);" required>
					<option selected>--SELECT--</option>
					<?php $sq=mysqli_query($con,"SELECT supplier_name from delivery");
					
					while($r= mysqli_fetch_array($sq)){ ?>
					<option><?php echo $r['supplier_name']; ?></option>
					<?php }?>
				</select>
				<div id="date"></div><br>
				<input type="Submit" name="receipt_button"  style='width:57%; margin-left:34%; padding-left: 2%;' value="Generate" /><br><br>
				
				</form><br><br>
				</div>
			</div>
		</div>
		
	<div style="margin-top:-20px;">
  		<div id="wrapper1">
        	<div id="receipt2">     
				<h1 class="label1" style="margin-left:0%;">Sales Receipt</h1>
				<form name="reform" method="POST" action="gen_receipt1.php" id="receipt" enctype="multipart/form-data">
				<label style="margin-left:4%; font-size:130%;"><b>Customer:</b></label>
				<?php $sq1=mysqli_query($con,"SELECT * from customer");?>
					<select name="cust" id="cust" style="margin-left:8%; width:50%;" onchange="ajaxFunction1(this.value);">
						<option selected>--SELECT--</option>
							<?php	while($r1= mysqli_fetch_array($sq1)){ ?>
						<option><?php echo $r1['sold_to']; ?></option>
							<?php }?>
					</select>
				<div id="salesdate"></div><br>
				<input type="Submit" name="sales_button" style='width:57%; margin-left:38%; padding-left: 2%;' value="Generate"/><br><br>
				</form><br><br>
			</div>
		</div>
	</div>	
</div>
</body>
</html>
<script type="text/javascript">
function ajaxFunction(str)
{ 
	
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }
function stateChanged() 
    {
    if(httpxml.readyState==4)
      {
document.getElementById("date").innerHTML=httpxml.responseText;
document.getElementById("msg").style.display='none';

      }
    }
	var url="loaddate.php";
url=url+"?txt="+str;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("msg").style.display='inline';

  }
  
  function ajaxFunction1(str1)
{ 
	
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }
function stateChanged() 
    {
    if(httpxml.readyState==4)
      {
document.getElementById("salesdate").innerHTML=httpxml.responseText;
document.getElementById("msg").style.display='none';

      }
    }
	var url="loaddate2.php";
url=url+"?txt="+str1;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("msg").style.display='inline';

  }
</script>
