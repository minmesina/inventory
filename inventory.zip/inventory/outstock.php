<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
?>
<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/cont_style.css">
	<title></title>
</head>
<body background="images/bg1.jpg">
<div class="container">
	<div>
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="list">     
					<h1 class="label1">Out of Stock</h1>
					<table border="1" width="100%" style="border: 2px dotted #31b7f1;">
					<thead>
						<th>Item Name<br></th>
						<th>Quantity<br></th>
					</thead>
					<?php
					$result=mysqli_query($con,"select * from item where item_quantity =0");
					while($row = mysqli_fetch_array($result))
							{ ?>
							<tr>            	
								<td style="text-align:left;">&emsp;<?php echo $row['item_name']?></td>
								<td width="20%"><?php echo $row['item_quantity']?></td>	
							</tr>                      
						<?php } ?>
					</table>
					</div>
				</div>
			</div>
		</div>
	</div>	
	</div>
</body>
</html>