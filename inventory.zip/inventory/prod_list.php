<!DOCTYPE html>
<?php 
require_once("includes/connection.php");
?>
<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<script language="JavaScript" type="text/javascript">
  function login(showhide){
    if(showhide == "show"){
        document.getElementById('popup').style.visibility="visible";
        
    }else if(showhide == "hide"){
        document.getElementById('popup').style.visibility="hidden";
    }
  }
  </script>
	<title></title>
</head>
<body>
	<div class="container">
		<?php if (function_exists('hdr')){
	      hdr();
	    }?>
	    <div  id='cssmenu'>
		  	<ul>
		  		
		   		<li class='has-sub' ><a href='index.php'><span>Home</span></a></li>
		   		<li class='active' ><a href='prod_list.php'><span>Products</span></a></li>  
				<li class='has-sub' ><a href='prod_list.php'><span>About&nbsp;Us</span></a></li>
				<li  class=' has-sub'><a  href="javascript:login('show')"><span>Login</span></a></li>
			</ul>
		</div>
	<br>
	
 
	 <div style="margin-left:40px;">
  <?php  
      $result=mysqli_query($con,"SELECT * from product");
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_array($result)) {
          ?>
           <form method="post" action="? " enctype="multipart/form-data">
          <input type="hidden" name="id" id="hiddenField" value="<?php echo $row['id']?>" />
          <div style="width: 25%; height:260px; float:left; position: relative; margin-top: 10px;">
              <a href="guestDetail.php?id=<?php echo $row["id"]?>"><br><img src="prod_image/<?php echo $row['img1']; ?>"></a>
                       <h4><?php echo $row['name']?></h4>
                        <?php echo $row['type']?><br />
                        <?php echo $row['price']?><br />
                        <?php echo $row['description']?></th>
              </form> 
              </div>                 

          </form>
   <?php }} 
    ?>
    </div>
	

	</div>

	<div style="padding-left:100px;" id="popup">
  		<div class="container1">
    		<div id="container_demo">
      			<div id="wrapper">
        			<div id="login">
          			<form name="loginform" id="loginform" action="checkuser.php" method="POST">
            		<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="index.php">X</a>
            		<h1>LOGIN GUEST!</h1> 
            		<p> 
                	<label for="username" class="uname" data-icon="u" > User ID </label>
                	<input  id="username" name="un" required="required" type="text" placeholder="eg. myusername "/>
              		</p>
              
              <p> 
                <label for="password" class="youpasswd" data-icon="p"> Password </label>
                <input id="password" name="pw" required="required" type="password" placeholder="eg. p4ssword" /> 
              </p>  
               
              <p  class="login button"> 
                <input type="submit" name="login" value="Login">
              </p>  
          </form>                         
    </div>
    </div>
    </div>
</div>
  </div>

</body>
</html>
