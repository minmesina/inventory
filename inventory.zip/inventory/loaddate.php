<?Php

require_once("includes/connection.php");
$in=$_GET['txt'];

$msg="";
$msg .="<label style='margin-left:4%; font-size:120%;'><b>Delivery Date:</b></label>
		<select name='deldate' id='deldate' style='margin-left:0%; width:50%;'>";
	$s=mysqli_query($con,"select * from delivery where supplier_name like '$in'");
	$msg .="<option id='val'>--SELECT--</option>";
	while($row=mysqli_fetch_array($s)){
		
	$del_date=$row['delivery_date'];
	$date = DateTime::createFromFormat('Y-m-d', $del_date);
	$date_del=$date->format('M j, Y');
	
	$msg .="<option id='val'>"; $msg .=$date_del; $msg .="</option>";		
	}
		
$msg .="</select>";
echo $msg;
?>