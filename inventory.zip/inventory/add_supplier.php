<!DOCTYPE html>
<?php 
include("cssmenu.php");
	require_once("includes/connection.php");
?>
<html>
<head>
	<link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<script language="JavaScript" type="text/javascript">
	  
	</script>
</head>
<body>
<div class="container">
	<div style="padding-left:100px; margin-top:-20px; margin-left:-4%;" id="popup1">
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="delivery">
						<form name="myForm" method="POST" action="prod_delivery.php" id="myform" enctype="multipart/form-data">
						
						
						<label>Supplier Name:</label><br><input type="text" id="s_name" name="s_name" /><br>
						
						<input type="Submit" name="add" class="add" value="Enter" />
						
						
					</form>
						<?php
						
						if(isset($_POST['add'])){ 
							$s_name=$_POST['s_name'];
							$date=date("Y/m/d");
								
									$sql2 = mysqli_query($con,"INSERT INTO delivery(supplier_name,delivery_date,total_price) VALUES('$s_name','$date','0')");
						}		
						?>
						
					    </div>                   
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
