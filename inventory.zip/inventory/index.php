<!DOCTYPE html>
<html>
<head>
	 <link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
<script language="JavaScript" type="text/javascript">
  function login(showhide){
    if(showhide == "show"){
        document.getElementById('popup').style.visibility="visible";
        
    }else if(showhide == "hide"){
        document.getElementById('popup').style.visibility="hidden";
    }
  }
</script>
	<title>MB Merchandising</title>
</head>
<body background="images/bg1.jpg">
	<div class="container">
		<?php if (function_exists('hdr')){
	      hdr();
	    }?>
	    <div  id='cssmenu'>
		  	<ul>
		   		<li class='active' ><a href='index.php'><span>Home</span></a></li> 
				<li  class=' has-sub'><a  href="javascript:login('show')"><span>Login</span></a></li>
			</ul>
		</div>
		<br>
		<div id= "slider" style='border-radius: 10px 10px 10px 10px; border: 10px outset cyan;'>
			<img src = "images/img1.jpg"/>
			<img src = "images/img2.jpg"/>
		</div>
	</div>

	<div style="padding-left:100px;" id="popup">
  		<div class="container1">
    		<div id="container_demo">
      			<div id="wrapper">
        			<div id="login">
					<form name="loginform" id="loginform" action="login.php" method="POST">
						<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="index.php">X</a>
						<h1>LOGIN GUEST!</h1> 
						<p> 
							<label for="username" class="uname" data-icon="u" > User ID </label>
							<input  id="username" name="un" required="required" type="text" placeholder="eg. myusername "/>
						</p>
						<p> 
							<label for="password" class="youpasswd" data-icon="p"> Password </label>
							<input id="password" name="pw" required="required" type="password" placeholder="eg. p4ssword" /> 
						</p>  
						<p  class="login button"> 
							<input type="submit" name="login" value="Login">
						</p>  
					</form>                         
					</div>
				</div>
			</div>
		</div>
  </div>


</body>
</html>
