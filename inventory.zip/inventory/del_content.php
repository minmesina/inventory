<?php  
error_reporting(E_ALL ^ E_DEPRECATED);
require_once("includes/connection.php");

 $res = $_GET['id'];
	$result = mysqli_query($con,"SELECT * FROM cart WHERE id='$res'");
	
		$sql="DELETE FROM cart WHERE id = '$res'";
		$result=mysqli_query($con,$sql);
?>
	
	<script>
	document.location = "mycart.php"
	</script>