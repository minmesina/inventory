<?Php
require_once("includes/connection.php");
$in=$_GET['txt'];

$msg="";
$msg .="<label style='margin-left:4%; font-size:120%;'><b>Sales Date:</b></label>
		<select name='salesdate' id='salesdate' style='margin-left:8%; width:50%;'>";
	
	$sq=mysqli_query($con,"select customer_id from customer where sold_to like '$in'");
	$row1=mysqli_fetch_array($sq);
	$id=$row1['customer_id'];
	$s=mysqli_query($con,"select * from sales where customer_id like '$id'");
	$msg .="<option id='val'>--SELECT--</option>";
	while($row=mysqli_fetch_array($s)){
		
	$sales_date=$row['sales_date'];
	$date = DateTime::createFromFormat('Y-m-d', $sales_date);
	$date_sales=$date->format('M j, Y');
	
	$msg .="<option id='val'>"; $msg .=$date_sales; $msg .="</option>";		
	}
		
$msg .="</select>";
echo $msg;
?>