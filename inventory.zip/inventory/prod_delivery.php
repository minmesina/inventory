<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
?>
<html>
<head>
	<link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/cont_style.css">
	<title>Product Delivery</title>
</head>
<body background="images/bg1.jpg">											
<div class="container">
	<div style="margin-top:20px; margin-left:-40%;">
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="delivery">
						<?php
						$s_name = $_GET['supplier_name'];
						$date = $_GET['date_del'];		
						$sql1 = "Select delivery_ID as del_id from delivery where supplier_name like '$s_name' && delivery_date like '$date'";
						$result1 = mysqli_query($con,$sql1);
						$row= mysqli_fetch_assoc($result1);	
						$del_id=$row['del_id'];
						
						?>
						
					<form name="myForm" method="post" action="" id="myform" enctype="multipart/form-data">
						<h2 class="label5">Item Delivered </h2>
						<input type="hidden" name="s_name" id="s_name" value="<?php echo $s_name; ?>"><br>
						<input type="hidden" name="del_id" id="del_id" value="<?php echo $del_id; ?>"><br>
						<label>Item Name:</label><br><input type="text" id="itemm" onkeyup="ajaxFunction(this.value);" name="itemm" /><br>
						<div id="suggest"></div>
						<label>Item Type:</label><br>
						<select name="prod_type" id="opt">
						<?php
						$result=mysqli_query($con,"select * from category");
						while($row = mysqli_fetch_array($result)){ 
						?>		
						<option><?php echo $row['category_name']?></option>                      
						<?php } ?>		
						</select><br>
						<label>Unit Price:</label><br><input type="Text" name="unit_price" id="unit_price" required/><br>
						<label>Quantity:</label><br><input type="Text" name="delquantity" id="delquantity" style="margin-left:20%;" required/><br>
						<br>
						<input type="Submit" name="add" class="add" value="Add item" />
						<?php
						if(isset($_POST['add'])){ 
							$s_name=$_POST['s_name'];
							$del_id=$_POST['del_id'];
							$prod_name=$_POST['itemm'];
							$prod_type=$_POST['prod_type'];
							$unit_price=$_POST['unit_price'];
							$delquantity=$_POST['delquantity'];
								$sql1= mysqli_query($con,"SELECT category_id as cat_id from category where category_name='$prod_type'");
								$row= mysqli_fetch_array($sql1);
								$catid=$row['cat_id'];
									mysqli_query($con,"INSERT INTO delivery_list (del_id,item_category_id,item_name,item_quantity,unit_price) VALUES ('$del_id','$catid','$prod_name','$delquantity','$unit_price')");
										echo "<script> alert('Succesfully Added!')</script>";
							$q=mysqli_query($con,"SELECT item_name from item where item_name like '$prod_name'");	
							$n=mysqli_num_rows($q);
							$q1=mysqli_query($con,"SELECT item_id as i_id, item_quantity as i_quantity from item where item_name like '$prod_name'");		
							$rr = mysqli_fetch_array($q1);	
							$i_id=$rr['i_id'];
										$pre_quantity=$rr['i_quantity'];
										$total_quantity=$pre_quantity+$delquantity;
							$cnt=1;			
										if($n>=$cnt){
										$quer1=mysqli_query($con,"DELETE FROM item where item_name='$prod_name'");
										}
										$c=mysqli_query($con,"insert into item (item_id,item_name,item_category_id,item_quantity,selling_price) values ('$i_id','$prod_name','$catid','$total_quantity','0')");
						}
						
						
						
						?>
						
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>	
 </div>  
	<div class="h">
		<h4>Official List of Item Delivered <br> &nbsp;&nbsp;by: <?php echo $s_name; ?> </h4>
		
	</div>
  <table border="1px solid gray;" align="center" class="official">
		<thead>
		<th> &emsp; &emsp;Item Name &emsp;&emsp; </th>
		<th> &nbsp;Quantity&nbsp; </th>
		<th> &nbsp;Unit Price&nbsp; </th>
		</thead>
		<?php $disp=mysqli_query($con,"select item_name, item_quantity, unit_price from delivery_list where del_id like '$del_id'");
		$total = 0;	
		$subtotal=0;
		while($row = mysqli_fetch_array($disp)){?>
		<tr class="data">
		<td><?php echo ($row['item_name']); ?></td>
		<td><?php echo ($row['item_quantity']); ?></td>
		<td><?php echo ($row['unit_price']); ?></td>
		</tr>
		<?php 
		$subtotal= $row['item_quantity'] * $row['unit_price'];
		$total += $subtotal;
		$numx=mysqli_query($con,"SELECT * from delivery where supplier_name like '$s_name' && delivery_date like '$date'");
		$x=mysqli_num_rows($numx);		
		$cntx=1;			
			if($x>=$cntx){
			mysqli_query($con,"DELETE FROM delivery where supplier_name like '$s_name' && delivery_date like '$date'");
			}
		mysqli_query($con,"insert into delivery(delivery_ID,delivery_date,total_price,supplier_name) values ('$del_id','$date','$total','$s_name')");
						} ?>
		<h5 style="position:relative; margin-top: -3%; margin-left: 75%;"><i>Total: <?php echo $total; ?></i></h5> 
	</table>
<script>

function func(sel) {
    document.getElementById("itemm").value = sel.options[sel.selectedIndex].text;
	var dropdown = document.getElementById("s1");
    var current_value = dropdown.options[dropdown.selectedIndex].value;
        document.getElementById("s1").style.display = "none";   
}
</script>


</body>
</html>

<script type="text/javascript">
function ajaxFunction(str)
{
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }
function stateChanged() 
    {
    if(httpxml.readyState==4)
      {
document.getElementById("suggest").innerHTML=httpxml.responseText;
document.getElementById("msg").style.display='none';

      }
    }
	var url="suggestion.php";
url=url+"?txt="+str;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("msg").style.display='inline';

  }
</script>