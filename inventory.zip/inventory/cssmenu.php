<!DOCTYPE html>
<?php 
	require_once("includes/connection.php");
?>
<html>
<head>
	<link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<script language="JavaScript" type="text/javascript">
	  function supplier(showhide){
		if(showhide == "show"){
			document.getElementById('popup').style.visibility="visible";
			
		}else if(showhide == "hide"){
			document.getElementById('popup').style.visibility="hidden";
		}
	  }
	</script>
	<script language="JavaScript" type="text/javascript">
	  function customer(showhide){
		if(showhide == "show"){
			document.getElementById('popup1').style.visibility="visible";
			
		}else if(showhide == "hide"){
			document.getElementById('popup1').style.visibility="hidden";
		}
	  }
	</script>
</head>
<body>
	<div class="container">
	     <div  id='cssmenu'>
		  	<ul>
		   		<li class='has-sub'><a href="userIndex.php"><span>Home</span></a></li>
		   		<li class='has-sub'>
					<form><input type="radio"><span>Manage</span></form>
						<ul class="submenu">
							<li><a href="javascript:supplier('show')">Product&nbsp;Delivery</a></li>
							<li><a href="javascript:customer('show')">Sales</a></li>
							<li><a href="set_price.php">Product&nbsp;Pricing</a></li>
							<li><a href="category.php">Product&nbsp;Category</a></li>
							
						</ul>
				</li>
				<li class='has-sub'>
					<form><input type="radio"><span>Products</span></form>
						<ul class="submenu">
							<li><a href="recently.php">Recently&nbsp;Added</a></li>
							<li><a href="userList.php">Current&nbsp;Stocks</a></li>
							<li><a href="outstock.php">Out&nbsp;of&nbsp;Stock</a></li>
						</ul>
				</li>
				<li class='has-sub'><a href="reports.php"><span>Reports</span></a></li>
				<li class='has-sub'><a href="receipt.php"><span>Receipt</span></a></li>  				
				<li  class=' has-sub'><a  href="logout.php"><span>Logout</span></a></li>
			</ul>
		</div>
	</div>
	
	<div style="padding-left:100px;" id="popup">
  		<div class="container1">
    		<div id="container_demo">
      			<div id="wrapper">
        			<div id="login">
						<form name="supplierform" id="supplierform" action="prod_delivery.php" method="GET">
							<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="userIndex.php">X</a>
							<h1>Supplier Name:</h1> 
							<input  id="supplier_name" name="supplier_name" required="required" type="text"/>
							<input type="date" name="date_del" max="<?php echo $date; ?>" >
							<input type="submit" name="button" value="Enter" >
							<?php
						if(isset($_GET['button'])){ 
						$s_name = $_GET['supplier_name'];
						$date1= $_GET['date_del'];
						?><script>alert(<?php echo $s_name ?>);</script>
						<?php $sql = mysqli_query($con,"Insert into delivery (delivery_date, total_price, supplier_name) values ('$date1',0,'$s_name')");
						}
						?>
						</form>                      
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div style="padding-left:100px;" id="popup1">
  		<div class="container1">
    		<div id="container_demo">
      			<div id="wrapper">
        			<div id="login">
						<form name="customerform" id="customerform" action="sales.php" method="GET">
							<a style="float:right; margin-top:-20px; font-size:24px; font-weight:bold;" href="userIndex.php">X</a>
							<label>Customer Name:</label><a  href="customer.php"><span class="new" style="margin-left:0%; margin-top:17%;">New Customer</span></a><br><br>
							<select name="cust_name" id="cust_name" onchange="rec_sales(this.value)">
								<option>--Select--</option>
									<?php
									$result=mysqli_query($con,"select sold_to from customer");
									while($row = mysqli_fetch_array($result)){ 
									?>		
								<option><?php echo $row['sold_to']?></option>                      
									<?php } ?>		
							</select><br>
							<input type="date" name="date_sales"/>
							<label>Amount Paid:</label><input  id="amount" name="amount" required="required" type="text"/>
							<input type="submit" name="button1" value="Enter" >
							
						</form>                      
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
