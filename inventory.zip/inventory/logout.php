<?php 
require_once("includes/connection.php");
error_reporting(E_ALL ^ E_DEPRECATED);
session_start();
unset($_SESSION['account_ID']);
session_destroy();

header("location: index.php");
?>
