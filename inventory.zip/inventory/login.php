<?php
require_once("includes/connection.php");

if (isset($_POST['login'])) {
$UserName=$_POST['un'];
$Password=$_POST['pw'];
$result=mysqli_query($con,"select * from accounts where username='$UserName' and password='$Password'")or die (mysqli_error());
		
$count=mysqli_num_rows($result);
$row=mysqli_fetch_array($result);
		
		if ($count > 0){
		session_start();
		$_SESSION['account_ID']=$row['account_ID'];
		header('location:userIndex.php');
		}else{
		header('location:index.php');
		}
}
?>

