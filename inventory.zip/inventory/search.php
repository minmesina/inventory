<?Php
require "config.php";
$in=$_GET['txt'];
if(!ctype_alnum($in)){
exit;}

$msg="";
$msg="
	<div class='container'>
	<div>
  		<div class='container2'>
    		<div id='container_demo1'>
      			<div id='wrapper1'>
				<div id='result'>     
<h1 class='label1'>Current Stocks</h1>
<table border='1' width='100%' style='border: 2px dotted #31b7f1;'>
		<thead>
			<th>Item Name<br></th>
			<th>&emsp;Quantity&emsp;<br></th>
		</thead>
		";
if(strlen($in)>0 and strlen($in) <20 ){
$sql="select item_name, item_quantity from item where item_name like '$in%'";

foreach ($dbo->query($sql) as $nt) {
$msg .="<tr><td style='text-align:left;'>$nt[item_name]</td>
		<td width='20%'>$nt[item_quantity]</td></tr>";
}
		}
$msg .='
		</table>
		</div></div>
		</div></div>
		</div></div>';
echo $msg;
?>