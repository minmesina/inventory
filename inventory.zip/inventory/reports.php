<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
?>
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.0/jquery.min.js"></script>



<script type="text/javascript">
$(document).ready(function() {
    
 

   
$('button').click(function () {

	$.post('create_result.php', $('form').serialize(), function () {
		$('div#wrapper').fadeOut( function () {

        $('#success').show();

		});
	});
	return false;
});
});





</script>

	 <link rel="stylesheet" href="css/style.css">
	<title></title>
</head>
<body background="images/bg1.jpg">		
	<div class="container">
	<div style="padding-left:100px; margin-left:-50%;">
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="report1">
					<form action="gen.php" method="post">
						<h1 class="label1">Summary of Item Bought</h1>
						<?php $date=date("m/d/y"); ?>
						<h2 class="label2"> From: </h2>
						<input type="date" name="sb_from" max="<?php echo $date; ?>" >
						<h2 class="label2"> To: </h2>
						<input type="date" name="sb_to" max="<?php echo $date; ?>"><br>
						<input type="Submit" name="sb_button" value="Generate Report">
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div style="padding-left:100px; margin-top:-59%; margin-left:42%;">
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="report">
					<form action="gen1.php" method="post">
						<h1 class="label1"> Loss and Profit</h1>
						<?php $date=date("m/d/y"); ?>
						<h2 class="label2"> From: </h2>
						<input type="date" name="lp_from" max="<?php echo $date; ?>" >
						<h2 class="label2"> To: </h2>
						<input type="date" name="lp_to" min="<?php echo $date; ?>"><br>
						<input type="Submit" name="lp_button" value="Generate Report">
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>	
</div>
</body>
</html>