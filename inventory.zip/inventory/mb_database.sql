-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2016 at 01:07 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mb_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `account_ID` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`account_ID`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(25, 'bearing'),
(26, 'headtractor'),
(27, 'fordtractor'),
(28, 'oil ring'),
(30, 'yanza');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(3) NOT NULL,
  `sold_to` varchar(50) NOT NULL,
  `TIN` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `business_style` varchar(20) NOT NULL,
  `terms` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `sold_to`, `TIN`, `address`, `business_style`, `terms`) VALUES
(15, 'Armand Ramos', '', 'Cabanatuan City', '', ''),
(16, 'Reyner Ortiz', '', 'San Antonio', '', ''),
(17, 'Alejandro Mesina', '', 'San Antonio', '', ''),
(19, 'Mar San Jose', '1234', 'San Jose', '', ''),
(20, 'Jasmin', '', 'Nueva Ecija', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `delivery_ID` int(10) NOT NULL,
  `delivery_date` varchar(10) NOT NULL,
  `total_price` int(10) NOT NULL,
  `supplier_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`delivery_ID`, `delivery_date`, `total_price`, `supplier_name`) VALUES
(312, '2016-10-16', 2208, 'Davids'),
(323, '2016-10-18', 1734, 'ACE'),
(324, '2016-10-25', 947, 'shanys');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_list`
--

CREATE TABLE `delivery_list` (
  `del_id` int(3) NOT NULL,
  `item_category_id` int(3) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `item_quantity` int(5) NOT NULL,
  `unit_price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_list`
--

INSERT INTO `delivery_list` (`del_id`, `item_category_id`, `item_name`, `item_quantity`, `unit_price`) VALUES
(312, 25, '607 zz', 2, 47),
(312, 25, '262 Nachi', 7, 60),
(312, 25, '627', 3, 60),
(312, 25, '609 NTN', 2, 52),
(312, 25, '628 Nachi', 7, 60),
(312, 25, '629 NTN', 2, 60),
(312, 25, '6900 E20', 2, 40),
(312, 25, '1680 Thailand', 1, 30),
(312, 25, '69 22', 4, 120),
(312, 25, '6000 ZNSK', 4, 70),
(323, 25, '6001 ZZ Nachi', 1, 40),
(323, 25, '6001 1NKSE Nachi', 1, 40),
(323, 25, '6002 NSK', 4, 37),
(323, 25, '6002 NTN', 1, 35),
(323, 25, '6002 Nachi', 5, 37),
(323, 25, '6003 zz Nachi', 5, 65),
(323, 25, '6004 Nachi', 3, 45),
(323, 25, '6005', 4, 72),
(323, 25, '6006 koyo', 4, 85),
(323, 25, '6006 ZZ Nachi', 2, 99),
(324, 25, '6007 zz Nachi', 1, 120),
(324, 25, '6008 NSK', 1, 171),
(324, 25, '6008 tag', 2, 170),
(324, 25, '6008 NR NTN', 2, 158);

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(25) NOT NULL,
  `item_category_id` int(11) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `selling_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`item_id`, `item_name`, `item_category_id`, `item_quantity`, `selling_price`) VALUES
(142, '607 zz', 25, 0, 50),
(143, '262 Nachi', 25, 5, 70),
(144, '627', 25, -2, 70),
(145, '609 NTN', 25, -1, 60),
(146, '628 Nachi', 25, 7, 70),
(147, '629 NTN', 25, 2, 0),
(148, '6900 E20', 25, -4, 50),
(149, '1680 Thailand', 25, -1, 40),
(150, '69 22', 25, 0, 130),
(151, '6000 ZNSK', 25, -4, 80),
(152, '6001 ZZ Nachi', 25, 0, 50),
(153, '6001 1NKSE Nachi', 25, 0, 50),
(154, '6002 NSK', 25, 4, 40),
(155, '6002 NTN', 25, 1, 40),
(156, '6002 Nachi', 25, 0, 40),
(157, '6003 zz Nachi', 25, 3, 70),
(158, '6004 Nachi', 25, 3, 50),
(159, '6005', 25, 3, 80),
(160, '6006 koyo', 25, 3, 90),
(161, '6006 ZZ Nachi', 25, 2, 0),
(162, '6007 zz Nachi', 25, 0, 130),
(163, '6008 NSK', 25, 0, 180),
(164, '6008 tag', 25, 2, 180),
(165, '6008 NR NTN', 25, 2, 160);

-- --------------------------------------------------------

--
-- Table structure for table `item_list_sold`
--

CREATE TABLE `item_list_sold` (
  `sales_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `item_category_id` int(10) NOT NULL,
  `item_sold_name` varchar(15) NOT NULL,
  `quantity_sold` int(5) NOT NULL,
  `selling_price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_list_sold`
--

INSERT INTO `item_list_sold` (`sales_id`, `item_id`, `item_category_id`, `item_sold_name`, `quantity_sold`, `selling_price`) VALUES
(89, 142, 25, '607 zz', 2, 50),
(89, 151, 25, '6000 ZNSK', 3, 80),
(89, 160, 25, '6006 koyo', 1, 90),
(93, 151, 25, '6000 ZNSK', 2, 80),
(93, 156, 25, '6002 Nachi', 5, 40),
(96, 144, 25, '627', 5, 70),
(96, 148, 25, '6900 E20', 1, 50),
(96, 157, 25, '6003 zz Nachi', 2, 70),
(96, 159, 25, '6005', 1, 80),
(96, 149, 25, '1680 Thailand', 2, 40),
(96, 151, 25, '6000 ZNSK', 1, 80),
(103, 150, 25, '69 22', 4, 130),
(103, 145, 25, '609 NTN', 3, 60),
(103, 152, 25, '6001 ZZ Nachi', 1, 50),
(103, 151, 25, '6000 ZNSK', 2, 80),
(104, 143, 25, '262 Nachi', 2, 70),
(104, 148, 25, '6900 E20', 5, 50),
(104, 153, 25, '6001 1NKSE Nach', 1, 50),
(104, 162, 25, '6007 zz Nachi', 1, 130),
(104, 163, 25, '6008 NSK', 1, 180);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `sales_date` varchar(10) NOT NULL,
  `total` int(11) NOT NULL,
  `amount_paid` int(11) NOT NULL,
  `customer_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sales_date`, `total`, `amount_paid`, `customer_id`) VALUES
(89, '2016-10-19', 430, 1000, 15),
(93, '2016-10-20', 360, 500, 16),
(96, '2016-10-22', 780, 800, 17),
(103, '2016-10-24', 910, 1000, 19),
(104, '2016-10-27', 750, 1000, 20),
(105, '2016-10-27', 0, 1000, 20),
(106, '2016-10-27', 0, 1000, 20),
(107, '2016-10-27', 0, 1000, 20),
(108, '2016-10-27', 0, 1000, 20),
(109, '2016-10-27', 0, 1000, 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`account_ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`delivery_ID`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `account_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `delivery_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;
--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
