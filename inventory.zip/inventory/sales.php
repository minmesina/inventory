<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
error_reporting(0);
?>
<html>
<head>
	<link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/cont_style.css">
	<title>Product Delivery</title>
</head>
<body background="images/bg1.jpg">

												
<div class="container">
    <div style="margin-top:-20px; margin-left:5%;">
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="sale" style="margin-left:-40%;">
						<?php
						if(isset($_GET['button1'])){ 
						$cust_name = $_GET['cust_name'];
						$amount = $_GET['amount'];
						$date=$_GET['date_sales'];;
						
						$sel_query1= mysqli_query($con,"SELECT customer_id as cust_id from customer where sold_to='$cust_name'");
						$row= mysqli_fetch_array($sel_query1);
						$cust_id=$row['cust_id'];
						$ins_query1 = mysqli_query($con,"Insert into sales(sales_date, total, amount_paid, customer_id) values('$date','','$amount','$cust_id')");
						}
						
						$sel_query2 = mysqli_query($con,"Select sales_id from sales where customer_id like '$cust_id' && sales_date like '$date'");
						$row1= mysqli_fetch_array($sel_query2);	
						$sales_id=$row1['sales_id'];
						?>
						
						<form name="myForm" method="POST" action="" id="myform" enctype="multipart/form-data">
							<h2 class="label5">Record Sales</h2>
							<input type="hidden" name="sales_id" id="sale_id" value="<?php echo $sales_id; ?>"/><br/>
							
							<?php $item_query=mysqli_query($con,"Select item_name from item where item_quantity !=0 && selling_price !=0"); ?>
							<label>Item Name:</label><br/>
							<select name="itemm" id="itemm" onchange="ajaxFunction(this.value);">
								<option>-SELECT-</option>
								<?php while($nt= mysqli_fetch_array($item_query)){ 
								$ii=$nt['item_name'];?>
								<option><?php echo $nt['item_name'] ?></option><br>
								<?php } ?>
							</select><br/></br>
							<div id="sold_info"></div>
						
							<label>Quantity Sold:</label><br><input type="Text" name="quantity" id="quantity" required/><br/><br/>
							<input type="Submit" name="add" class="add" value="Add item" />
							
							<?php
							if(isset($_POST['add'])){ 
								$sales_id=$_POST['sales_id'];
								$prod_name=$_POST['itemm'];
								$prod_type=$_POST['prod_type'];
								$s_price=$_POST['s_price'];
								$quantity=$_POST['quantity'];
								
								$sel_query4= mysqli_query($con,"SELECT category_id as cat_id from category where category_name='$prod_type'");
								$row3= mysqli_fetch_array($sel_query4);
								$catid=$row3['cat_id'];
									
								$sel_query5= mysqli_query($con,"SELECT item_id as item_id from item where item_name='$prod_name'");
								$row4= mysqli_fetch_array($sel_query5);
								$itemid=$row4['item_id'];
									
								$ins_query2 = mysqli_query($con,"INSERT INTO item_list_sold(sales_id,item_id,item_category_id,item_sold_name,quantity_sold,selling_price) VALUES ('$sales_id','$itemid','$catid','$prod_name','$quantity','$s_price')");				
								
								$q1=mysqli_query($con,"SELECT item_quantity as i_quantity from item where item_name like '$prod_name'");		
								$rr = mysqli_fetch_array($q1);	
								$pre_quantity=$rr['i_quantity'];
								$total_quantity=$pre_quantity-$quantity;
								
								$up_query=mysqli_query($con,"Update item set item_quantity=$total_quantity where item_name='$prod_name'");
							} 					
							?>	
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>	
 </div>  
 
	<div class="h">
		<h4 style="margin-top: 25%;">Official List of Items Sold<br/>&nbsp;&nbsp;by: <?php echo $cust_name; ?></h4>
	</div>
	<br><br>
    <table border="1px solid gray;" align="center" class="official">
		<thead>
		<th> &emsp; &emsp;Item Name &emsp;&emsp; </th>
		<th> &nbsp;Quantity&nbsp; </th>
		<th> &nbsp;Selling Price&nbsp; </th>
		</thead>
		
		<?php
		$sel_query6=mysqli_query($con,"select item_sold_name, quantity_sold, selling_price from item_list_sold where sales_id like '$sales_id'");
		$total = 0;	
		$subtotal=0;
		
		while($row5 = mysqli_fetch_array($sel_query6)){?>
		<tr class="data">
		<td><?php echo ($row5['item_sold_name']); ?></td>
		<td><?php echo ($row5['quantity_sold']); ?></td>
		<td><?php echo ($row5['selling_price']); ?></td>
		</tr>
		<?php 
		$subtotal= $row5['quantity_sold'] * $row5['selling_price'];
		$total += $subtotal;
		$query=mysqli_query($con,"Update sales set total=$total where customer_id='$cust_id' && sales_id ='$sales_id'");
		} ?>
		
		<h5 style="position:relative; margin-top: -3%; margin-left: 70%;"><i>Total: <?php echo $total; ?></i></h5>	 
	</table>
 
</body>
</html>
<script type="text/javascript">
function ajaxFunction(str)
{ 
	
var httpxml;
try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }
function stateChanged() 
    {
    if(httpxml.readyState==4)
      {
document.getElementById("sold_info").innerHTML=httpxml.responseText;
document.getElementById("msg").style.display='none';

      }
    }
	var url="loadcategory.php";
url=url+"?txt="+str;
url=url+"&sid="+Math.random();
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("msg").style.display='inline';

  }
</script>