<?php 
require_once("includes/connection.php");
?>
<?php	
	$cname = $_GET['selcat'];
	$del_q = mysqli_query($con,"SELECT category_id as id FROM category WHERE category_name='$cname'");
	$row_del = mysqli_fetch_array($del_q);
	$id=$row_del['id'];
	$sql=mysqli_query($con,"DELETE FROM category WHERE category_id = '$id'");
	echo "<script> alert('Successfully Deleted!');</script>";
	echo "<script>document.location = 'category.php'</script>";
	?>
