<div class="footer">
<link rel="stylesheet" type="text/css" href="css/style.css" />
	<footer align="center">Jhonnelyn Alvesor||Jasmin Mesina</footer>
			
</div>