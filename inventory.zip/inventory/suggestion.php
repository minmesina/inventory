<?Php
require "config.php";
$in=$_GET['txt'];


$msg="";
$msg="<select id='s1' size='2' onclick='func(this)'>";
if(strlen($in)>0 and strlen($in) <20 ){
$sql="select * from item where item_name like '$in%'";

$sql1= "SELECT count(item_name) as num FROM item where item_name like '$in%'";
foreach ($dbo->query($sql1) as $nt1) {
	$n=$nt1['num'];
	?><script type="text/javascript">
	function nul(){
        document.getElementById("s1").style.display = "none";
	}
<?php if ($n==0){
	nul();
}
?>	
	
</script>
<?Php

}

foreach ($dbo->query($sql) as $nt) {
$msg .="<option id='opt'>$nt[item_name]</option>";
}
}
$msg .='</select>';
echo $msg;

?>