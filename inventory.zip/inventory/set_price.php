<!DOCTYPE html>
<?php 
include("cssmenu.php");
require_once("includes/connection.php");
error_reporting(0);
?>

<html>
<head>
	<link href="1/js-image-slider.css" rel="stylesheet" type="text/css" />
	<script src="1/js-image-slider.js" type="text/javascript"></script>	
	<link rel="stylesheet" href="css/style.css">
	<title>Set Price</title>
</head>
<body background="images/bg1.jpg">
	<div class="container">
	<div>
  		<div class="container2">
    		<div id="container_demo1">
      			<div id="wrapper1">
        			<div id="set_price">
						<form method="POST" enctype="multipart/form-data">
							<h1 class="label1">Set Price</h1>
							<h2 class="label2">Product List:</h2>
							<select name="opt" id="opt" onchange="change(this)" style="margin-left:20%; width:50%;">
								<option selected>--Select--</option>
									<?php $result=mysqli_query($con,"select item_name from item");
									while($row = mysqli_fetch_array($result)){ ?>
								<option id="val" name="val"><?php echo $row['item_name']?></option>                      
									<?php } ?>
							</select><br>	
							
							<script type="text/javascript">
								function change(sel){	
								var itemx = sel.options[sel.selectedIndex].text
								window.location.href="?item_name="+itemx;}
							</script>	
							<h2 class="label2">Product Name:</h2>
							<?php $it=$_GET['item_name']; ?>
							<label class="label3"><?php echo $it; ?></label>
							<?php
								$sql=mysqli_query($con,"select * from item where item_name like '$it'");
								$row = mysqli_fetch_array($sql);
								$sq=mysqli_query($con,"select * from delivery_list where item_name like '$it'");
								$row1 = mysqli_fetch_array($sq);?>	
						
							<h2 class="label2">Unit Price:</h2>
							<label class="label3"><?php echo $row1["unit_price"]?></label>
							
											
							<h2 class="label2">Selling Price:</h2>
							<input type="Text" name="item_price" id="item_price"  value='<?php echo $row["selling_price"]?>' style="margin-left:20%; width:50%;"><br>
											
							<br><input type="Submit" id="button" name="button" value="SAVE" style="margin-left:20%; width:55%; padding-left:2%;">
						<?php
						if(isset($_POST['button'])){
							$item_name=$_GET['item_name'];
							$s_price=$_POST['item_price'];
							$up_query=mysqli_query($con,"Update item set selling_price=$s_price where item_name='$item_name'");
							echo "<script> alert('Succesfully Added!')</script>";
							echo "<script>document.location = 'set_price.php'</script>";
						} 					
						?>
						
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
