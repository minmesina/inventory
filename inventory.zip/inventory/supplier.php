<?php
//connection ng database
$con = mysqli_connect("localhost","root","");
	if(!$con)
		{
		die("Could not connect: " . mysqli_error());
		}
		mysqli_select_db("mb_database",$con);
		
	//get the value from index.php
	$s_name = $_POST['supplier_name'];
	$date=date("Y/m/d");
	//check if the username and password are in db
	$sql = "Insert into delivery(delivery_date, total_price, supplier_name) values('$date',0,'$s_name')";
	$result = mysqli_query($con,$sql);			
				header("location: Prod_delivery.php");			
?>